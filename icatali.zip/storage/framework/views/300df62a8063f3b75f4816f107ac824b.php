<img class="w-20" src="<?php echo e(asset('img/ICATALI-LOGO.png')); ?>" alt="">
<?php /**PATH C:\laragon\www\icatali\resources\views/components/application-mark.blade.php ENDPATH**/ ?>