<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Correo de contacto</h1>
    <p>Nombre: <?php echo e($data['nombre']); ?></p>
    <p>Nombre: <?php echo e($data['correo']); ?></p>
    <p>Nombre: <?php echo e($data['telefono']); ?></p>
    <p>Nombre: <?php echo e($data['mensaje']); ?></p>

</body>
</html>
<?php /**PATH C:\laragon\www\icatali\resources\views/mails/contacto.blade.php ENDPATH**/ ?>