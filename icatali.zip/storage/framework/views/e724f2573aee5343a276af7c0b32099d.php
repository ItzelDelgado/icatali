<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <style>
        ul {
            list-style-type: disc;
            padding-left: 1.5rem;
        }

        ol {
            list-style-type:decimal;
            padding-left: 1.5rem;
        }
    </style>

    <div class="container grid md:grid-cols-2 md:items-center gap-8 md:mt-20">
        <div id="default-carousel" class="relative w-full md:col-start-2 md:row-start-1" data-carousel="slide">
            <!-- Carousel wrapper -->
            <div class="relative h-96 overflow-hidden rounded-lg md:h-[27rem]">
                <!-- Item 1 -->
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="<?php echo e($producto->image); ?>" class="absolute inset-0 object-cover w-full h-full" alt="...">
                </div>
                <!-- Item 2 -->
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="<?php echo e($producto->image_pa); ?>" class="absolute inset-0 object-cover w-full h-full"
                        alt="...">
                </div>
                <!-- Item 3 -->
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="<?php echo e($producto->image_izq); ?>" class="absolute inset-0 object-cover w-full h-full"
                        alt="...">
                </div>
                <!-- Item 4 -->
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="<?php echo e($producto->image_der); ?>" class="absolute inset-0 object-cover w-full h-full"
                        alt="...">
                </div>
            </div>

            <!-- Slider indicators -->
            <div class="absolute z-30 flex -translate-x-1/2 bottom-5 left-1/2 space-x-3 rtl:space-x-reverse">
                <button type="button" class="w-3 h-3 rounded-full" aria-current="true" aria-label="Slide 1"
                    data-carousel-slide-to="0"></button>
                <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 2"
                    data-carousel-slide-to="1"></button>
                <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 3"
                    data-carousel-slide-to="2"></button>
                <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 4"
                    data-carousel-slide-to="3"></button>
            </div>
            <!-- Slider controls -->
            <button type="button"
                class="absolute top-0 start-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                data-carousel-prev>
                <span class="">
                    <svg class="w-8 h-8 text-green-800 dark:text-gray-800 rtl:rotate-180" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M5 1 1 5l4 4" />
                    </svg>
                    <span class="sr-only">Previous</span>
                </span>
            </button>
            <button type="button"
                class="absolute top-0 end-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                data-carousel-next>
                <span class="">
                    <svg class="w-8 h-8 text-green-800 dark:text-gray-800 rtl:rotate-180" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span class="sr-only">Next</span>
                </span>
            </button>
        </div>

        <div>
            <h2 class="font-bold text-2xl md:text-4xl mt-4"><?php echo e($producto->nombre); ?></h2>
            <div class="flex items-center gap-2 mt-4">
                <?php if($producto->precio_descuento): ?>
                    <p class="font-bold line-through text-gray-500">$ <?php echo e($producto->precio); ?> MXN</p>
                    <p class="font-bold">$ <?php echo e($producto->precio_descuento); ?> MXN</p>
                <?php else: ?>
                    <p class="font-bold">$ <?php echo e($producto->precio); ?> MXN</p>
                <?php endif; ?>


                <button class="bg-green-300 font-bold w-fit px-3 py-1 rounded-2xl"><a href="https://api.whatsapp.com/send?phone=5215532110142&text=Hola!%2C%20¿Me%20gustaría%20recibir%20mas%20información%3F">Comprar</a></button>
            </div>
            <p class="mt-4 descripcion"><span class="font-bold"></span> <?php echo $producto->descripcion; ?></p>
            <p class="font-bold mt-4">Beneficios:</p>
            <?php if($producto->beneficios): ?>
                <ul class="list-disc pl-6">
                    <?php $__currentLoopData = explode(',', $producto->beneficios); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e(trim($beneficio)); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <p class="font-bold mt-4">Ingredientes:</p>
            <?php if($producto->ingredientes): ?>
                <ul class="list-disc pl-6">
                    <?php $__currentLoopData = explode(',', $producto->ingredientes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingrediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e(trim($ingrediente)); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\icatali\resources\views/producto.blade.php ENDPATH**/ ?>