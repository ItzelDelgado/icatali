<x-admin-layout>
    @section('title', 'Panel de administración')
    <div>
        <h1 class="text-3xl text-center">Bienvenido al administrador de ICATALI</h1>
        <div class="flex justify-center mt-12 opacity-40">
            <img class="w-64" src="{{ asset('/img/flor_icatali.png') }}" alt="">
        </div>
    </div>
</x-admin-layout>
