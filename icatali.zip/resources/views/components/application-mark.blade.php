<img class="w-36" src="{{ asset('img/icatali_logo.png') }}" alt="">
