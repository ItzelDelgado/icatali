<img class="w-36" src="{{ asset('img/ICATALI-LOGO.png') }}" alt="">
