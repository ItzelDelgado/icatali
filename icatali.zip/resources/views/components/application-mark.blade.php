<img class="w-20" src="{{ asset('img/ICATALI-LOGO.png') }}" alt="">
