<img class="w-36" src="{{ asset('/img/flor_icatali.png') }}" alt="">
