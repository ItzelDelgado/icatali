<img class="w-64" src="{{ asset('/img/Logo-icatali-original.png') }}" alt="">
