<x-admin-layout>
    @section('title', 'Panel de administración')
    <div>
        <h1 class="text-3xl text-center">Bienvenido al administrador de ICATALI</h1>
    </div>
</x-admin-layout>
