<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Contacto'); ?>
    <div class="flex flex-col gap-8 items-center text-center mt-12">
        <h1 class="text-5xl">CREDITOS</h1>
        <h2 class="text-4xl">Instituto de Ciencias Aplicadas y Tecnología</h2>
        <div class="flex flex-col gap-8">
            <h2 class="text-4xl">Idea y Líder de desarrollo</h2>
            <p class="text-2xl">Selene Marisol Martínez Ramírez</p>
        </div>
        <div class="flex flex-col gap-8">
            <h2 class="text-4xl">Desarrollo</h2>
            <p class="text-2xl">Itzel Azucena Delgado Díaz</p>
        </div>
        <div class="flex flex-col gap-8">
            <h2 class="text-4xl">Diseño Visual</h2>
            <p class="text-2xl">Itzel Azucena Delgado Díaz</p>
            <p class="text-2xl">Selene Marisol Martínez Ramírez</p>
        </div>
        <div class="flex flex-col gap-8">
            <h2 class="text-4xl">Evaluaciones</h2>
            <p class="text-2xl">Neider</p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\icatali\resources\views/creditos.blade.php ENDPATH**/ ?>