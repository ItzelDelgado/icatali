<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Preguntas frecuentes'); ?>
    <h1
        class="bg-[url('../../../icatali/public/img/decoraciones/nube-preguntas.svg')] bg-no-repeat bg-cover h-52 flex justify-center items-center text-4xl mb-8 bebas ">
        ¿Como podemos ayudarte?</h1>
    <img class="hidden xl:block w-40 absolute lg:top-[43%] lg:right-[84%] rotate-[123deg] " src="<?php echo e(asset('img/decoraciones/plantita-1.svg')); ?>" alt="">
    <img class="hidden xl:block w-40 absolute lg:top-[50%] lg:right-[9%] " src="<?php echo e(asset('img/decoraciones/costal-semillas.svg')); ?>" alt="">
    <div class="max-w-[800px] mx-auto">
        <div class="w-full">
            <?php $__currentLoopData = $preguntas_frecuentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta_frecuente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div x-data="{ open: false }" class="relative" x-on:click.outside="open = false">
                    <!-- Botón del dropdown -->
                    <div @click="open = !open"
                        class="w-full flex justify-center items-center bg-verde-icatali p-2 border-2 md:gap-2 gap-1 rounded-2xl">
                        <h2 class="px-4 cursor-pointer w-11/12"><?php echo e($pregunta_frecuente->pregunta); ?></h2>
                        <i class="w-1/12 text-center fa-solid fa-circle-chevron-down text-2xl"></i>
                    </div>
                    <!-- Contenido del dropdown -->
                    <p x-show="open" class="dropdown-content relative bg-white px-4 mt-2 pb-2 w-full rounded-b-lg"
                        x-transition:leave-end="opacity-0 transform ">
                        <?php echo e($pregunta_frecuente->respuesta); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\icatali\resources\views/preguntas_frecuentes.blade.php ENDPATH**/ ?>