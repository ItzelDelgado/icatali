<?php
    $links = [
        // [
        //     //Informacion acerca del enlace
        //     'name' => 'Dashboard',
        //     'url' => route('admin.dashboard'),
        //     'active' => request()->routeIs('admin.dashboard'),
        //     'icon' => 'fa-solid fa-gauge-high',
        //     'can' => ''
        // ],
        [
            //Informacion acerca del enlace
            'name' => 'Comentarios',
            'url' => route('admin.comentarios.index'),
            'active' => request()->routeIs('admin.comentarios.*'),
            'icon' => 'fa-solid fa-comments',
            // 'can' => 'gestionar comentarios',
        ],
        [
            //Informacion acerca del enlace
            'name' => 'Preguntas Frecuentes',
            'url' => route('admin.preguntas_frecuentes.index'),
            'active' => request()->routeIs('admin.preguntas_frecuentes.*'),
            'icon' => 'fa-solid fa-circle-question',
            // 'can' => 'gestionar preguntas frecuentes',
        ],
        [
            //Informacion acerca del enlace
            'name' => 'Productos',
            'url' => route('admin.productos.index'),
            'active' => request()->routeIs('admin.productos.*'),
            'icon' => 'fa-solid fa-seedling',
            // 'can' => 'gestionar productos',
        ],
        [
            //Informacion acerca del enlace
            'name' => 'Usuarios',
            'url' => route('admin.users.index'),
            'active' => request()->routeIs('admin.users.*'),
            'icon' => 'fa-solid fa-user',
            // 'can' => 'gestionar usuarios',
        ],
        [
            //Informacion acerca del enlace
            'name' => 'Roles',
            'url' => route('admin.roles.index'),
            'active' => request()->routeIs('admin.roles.*'),
            'icon' => 'fa-solid fa-user-tag',
            // 'can' => 'gestionar roles',
        ],
        [
            //Informacion acerca del enlace
            'name' => 'Permisos',
            'url' => route('admin.permissions.index'),
            'active' => request()->routeIs('admin.permissions.*'),
            'icon' => 'fa-solid fa-key',
            // 'can' => 'gestionar permisos',
        ],
        // [
        //     //Informacion acerca del enlace
        //     'name' => 'Medicamentos',
        //     'url' => route('admin.medicines.index'),
        //     'active' => request()->routeIs('admin.medicines.*'),
        //     'icon' => 'fa-solid fa-prescription-bottle',
        // ],
        // [
        //     //Informacion acerca del enlace
        //     'name' => 'Solicitudes',
        //     'url' => route('admin.solicitudes.index'),
        //     'active' => request()->routeIs('admin.solicitudes.*'),
        //     'icon' => 'fa-solid fa-file-import',
        // ],
    ];
?>
<aside id="logo-sidebar"
    class="fixed top-0 left-0 z-40 w-44 h-screen pt-20 transition-transform -translate-x-full bg-white border-r border-gray-200 sm:translate-x-0 dark:bg-gray-800 dark:border-gray-700"
    :class="{
        '-translate-x-full': !open,
        'transform-none': open,
    }" aria-label="Sidebar">
    <div class="h-full px-3 pb-4 overflow-y-auto bg-white dark:bg-gray-800">
        <ul class="space-y-2 font-medium">

            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <li>
                        <a href="<?php echo e($link['url']); ?>"
                            class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group <?php echo e($link['active'] ? 'bg-gray-100' : ''); ?>">
                            

                            <i class="<?php echo e($link['icon']); ?> text-gray-500"></i>
                            <span class="ms-3"><?php echo e($link['name']); ?></span>
                        </a>
                    </li>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</aside>
<?php /**PATH C:\laragon\www\icatali\resources\views/layouts/includes/admin/aside.blade.php ENDPATH**/ ?>