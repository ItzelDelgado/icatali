<img class="w-36" src="<?php echo e(asset('/img/flor_icatali.png')); ?>" alt="">
<?php /**PATH C:\laragon\www\icatali\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>