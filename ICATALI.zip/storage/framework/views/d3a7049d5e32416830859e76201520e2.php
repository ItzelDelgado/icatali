<img class="w-36" src="<?php echo e(asset('img/icatali_logo.png')); ?>" alt="">
<?php /**PATH C:\laragon\www\ICATALI\resources\views/components/application-mark.blade.php ENDPATH**/ ?>