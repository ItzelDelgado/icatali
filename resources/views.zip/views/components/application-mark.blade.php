<img class="w-28" src="{{ asset('img/ICATALI-LOGO.png') }}" alt="">
